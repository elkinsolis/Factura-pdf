<html>
<head>
	<title>mis datos</title>
</head>
<body>
	<table border="1">
        <tr>
        	<td>Nombre</td>
        	<td>Apellido</td>
        </tr>
        <tr>
        	<td>Elkin</td>
        	<td>Solis</td>
        </tr>
	</table>
</body>
<html>